def vector_scalar_multiplication(scalar_value, row_vector):
    return None


def vector_add_operation(vector_1, vector_2):
    return None


def vector_subtract_operation(vector_1, vector_2):
    return None


def get_max_row_position(target_matrix, current_row_position, current_column_position):
    return None


def divided_by_pivot_value(row_vector, pivot_value):
    return None


def swap_row(matrix, source_row_number, target_row_number):
    return None


def gauss_jordan_elimination_process(target_matrix, pivot_row_position, column_position ):
    return None


def gauss_elimination_solution(target_matrix):
    return None
